# 原生控制链来源与重建

本工程交付的两个原生可执行文件来自本机 Rollio 已有的 debug 编译产物，复制后
仅执行了 `strip --strip-debug`。本次没有重新编译或修改它们。`file` 仍显示
`not stripped`，因为普通符号表保留；这不表示调试信息未剥离。

两个文件均报告：

```text
1.6.0-dev.38+g057d4142
build type: debug
build time: 2026-09-02T23:21:18+08:00
```

版本字符串来自二进制自身的 `--version`，不是本次 Git 查询。本次没有执行 Git。
来源目录 `/home/ubuntu/Github/rollio` 仅用于读取和记录来源，不是运行依赖。

## 二进制校验

| 文件 | 来源 SHA-256 | 交付 SHA-256 |
|---|---|---|
| `rollio-device-xrobot` | `83ecc53177df5201a7a29f9ff94dcd09c41d234948bd981ae4c378b6ebd8684d` | `6d1d2fd36019f28f5726a8a6f175a8ab49311130bd263af35524d29bbab1d53e` |
| `rollio-teleop-router` | `991ad8f49a798947e51aac65ae33010e404b8799abc08fa2e985906313893ddf` | `5dd46fec5cbc0e9101c621b496bc4eaa3d198e9a1e18b12db9b44a8dbdd1af6a` |

来源路径分别是上述目录的 `target/debug/rollio-device-xrobot` 和
`target/debug/rollio-teleop-router`。交付路径为工程的 `bin/`。完整文件哈希因
剥离调试信息而不同；本次直接解析 ELF64 little-endian section table、提取双方
`.text` 原始字节，逐字节比较相等，再计算 SHA-256：

| 文件 | `.text` 字节数 | 双方共同的 `.text` SHA-256 |
|---|---:|---|
| `rollio-device-xrobot` | 8,969,345 | `ebbd6f8385af66c6f46fc30bfd97527b9f0c2b40f4f67466b8aa37274ff74f7f` |
| `rollio-teleop-router` | 8,181,369 | `53925d23aa5ab0f7aeb517f8599ac49adb34f0c1229a7692bd3df4c20095e756` |

记录见 `vendor/native-provenance.json`，ELF header、Build ID、动态依赖和所需
符号版本见 `vendor/*.readelf.txt`。在工程根目录校验交付物：

```sh
sha256sum --check vendor/SHA256SUMS
sha256sum --check --quiet vendor/SOURCE_SHA256SUMS
```

这证明交付文件的机器代码段与指定来源文件一致；不证明当前源码快照经重新编译
必然产生这些二进制。本次未实施可重现构建，也不声称源码与旧二进制逐字节对应。

## 源码快照范围

`vendor/rollio-reference/` 保存 2026-09-25 从原工程只读复制的源码、原始
`Cargo.toml`、`Cargo.lock`、编译器配置及许可证。每个文件均与来源逐个校验；
2495 个文件的内容总计 17,203,722 字节，不包括文件系统目录开销。

- `robots/xrobot`：XR SDK 加载、输入解析、基变换、原生发布。
- `teleop-router`：控制组协调器、Grip/Trigger 路由、超时和模式处理。
- `rollio-types`、`rollio-bus`、`build-info`：消息 ABI、配置和主题定义、版本生成。
- `third_party/iceoryx2`、`third_party/ruckig`：本地 path 依赖的源码快照，包含其
  自身测试、示例、构建元数据和许可证；没有复制编译结果。
- NERO 的 `ipc/types.py`、`ipc/services.py`、`runtime/arm.py`、`query.py` 及原
  XR/NERO 配置：保留本工程 ABI、控制行为和参数的参考依据，不参与运行。

未复制 Rollio 的 `target/`、`.git/`、虚拟环境、录制数据、UI、摄像头或存储模块。
原始根工作区清单仍列出没有复制的应用，因此不要直接在快照根目录构建整个工作区。

原工程 `LICENSE` 为 GNU GPL version 3 文本，原样保留。iceoryx2 的 MIT/
Apache-2.0、Ruckig 的 MIT 及其包含的第三方许可证也保留。注册表 Rust 依赖的
版本和校验和保留在原 `Cargo.lock` 中，注册表依赖源码没有全部打包。

## 独立重建步骤

本次仅验证了准备脚本和文件一致性，没有运行编译。下列步骤为后续重建流程；
产物保持在 `work/native-build/target/`，不会自动替换已验证的 `bin/`。

需要 Linux x86_64、Rust/Cargo（iceoryx2 声明最低 Rust 1.85，使用 edition
2024）、Clang/Clang++、LLVM ar、C++20 标准库及 Linux 开发头文件。涉及 bindgen
配置时还需 libclang。依赖未缓存时，Cargo 需要访问注册表。本机记录时可用工具链
为 rustc 1.95.0、cargo 1.95.0；这不是原二进制编译器版本的证明。

从工程根目录执行：

```sh
python3 vendor/prepare_rebuild.py
cd work/native-build
cargo build -p rollio-device-xrobot -p rollio-teleop-router --bins
./target/debug/rollio-device-xrobot --version
./target/debug/rollio-teleop-router --version
```

准备脚本拒绝覆盖已有目录。它复制快照后只修改新构建树的三个文件：

1. 根 `Cargo.toml` 仅声明本次控制链所需的五个工作区成员，移除无关 FFmpeg patch。
2. `.cargo/config.toml` 只保留 Linux x86_64 Clang 设置，不引用原工程交叉编译工具。
3. `build-info/build.rs` 换成仅生成构建元数据的脚本，不执行 Git；重建版本明确
   标记为 `1.6.0-standalone.1+snapshot.20260925`。

控制实现源码、消息 ABI 和本地依赖源码不改。原 `Cargo.lock` 被复制到构建树；
缩小工作区可能导致 Cargo 重新整理锁文件，变化只发生在 `work/`。因此首轮不使用
`--locked`，也不承诺完全离线或逐字节重建。后续可对该构建树生成的新锁文件使用
`--locked`。

准备脚本和重建均不需要原 Rollio 目录。替换交付二进制前应重新运行本工程的原生
IPC 集成测试，并重新记录哈希、版本和 ABI 兼容性；本次没有执行替换。

## 运行平台与外部 SDK

交付文件是动态链接的 Linux x86_64 ELF，解释器为
`/lib64/ld-linux-x86-64.so.2`。两者需要 glibc 中最高 `GLIBC_2.34` 符号；router
还需要最高 `GLIBCXX_3.4.29`、`CXXABI_1.3.13` 符号。动态依赖只有标准系统库
`libgcc_s`、`libc`、加载器，以及 router 使用的 `libstdc++`、`libm`。
没有 RPATH/RUNPATH，也没有动态链接到 Rollio 目录。它们不能直接用于 Windows、
macOS 或 Linux ARM64；这些平台需要另行构建和验证。

真实 VR 输入仍需本机 XRoboToolkit PC Service 及其
`libPXREARobotSDK.so`，由 `config.json` 的 `sdk_library` 指定，默认位置为
`/opt/apps/roboticsservice/SDK/x64/libPXREARobotSDK.so`。这是按需加载的外部 SDK，
未打包到本工程，`readelf` 的静态 NEEDED 列表不会包含它。`--dry-run` 不加载 SDK。
真机控制另外需要 Python `arx5-interface`、Linux SocketCAN 和匹配的硬件配置。
仿真 demo 不需要 XR SDK 或 CAN。Python iceoryx2 必须与本次原生 ABI 匹配：0.9.1。
